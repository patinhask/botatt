const wibu = (pushname, prefix, botName, ownerName) => {
        return `
╔══✪〘 Informações 〙✪══
║
║───────⊹⊱✫⊰⊹───────
║➩ ❍ wa.me/5511934660977
║➩ ❍ Prefix: 「  ${prefix}  」
║➩ ❍ Criador: ${botName}
║➩ ❍ Nome: ${pushname}️
║➩ ❍ XP: ${reqXp}
║➩ ❍ Money: ${uangku}
───────⊹⊱✫⊰⊹───────


───────⊹⊱✫⊰⊹───────
║➩ ❍ *${prefix}info*
║➩ ❍ *${prefix}blocklist*
║➩ ❍ *${prefix}chatlist*
║➩ ❍ *${prefix}ping*
║➩ ❍ *${prefix}bugreport*
║➩ ❍ *${prefix}neonime*
║➩ ❍ *${prefix}pokemon*
║➩ ❍ *${prefix}loli*
║➩ ❍ *${prefix}waifu*
║➩ ❍ *${prefix}randomanime*
║➩ ❍ *${prefix}husbu*
║➩ ❍ *${prefix}husbu2*
║➩ ❍ *${prefix}wait*
║➩ ❍ *${prefix}nekonime*
║───────⊹⊱✫⊰⊹───────`
}
exports.wibu = wibu
